package com.csc340.project.posting;

public enum PostingStatus {
    ACTIVE,
    INACTIVE,
    CLAIMED
}
