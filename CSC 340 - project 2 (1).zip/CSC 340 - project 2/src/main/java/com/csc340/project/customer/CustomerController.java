package com.csc340.project.customer;
import com.csc340.project.posting.Posting;
import com.csc340.project.posting.PostingService;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/students")
public class CustomerController {

    @Autowired
    private CustomerService service;
    @Autowired
    private PostingService postingService;

    /**
     * Get a list of customers in the database
     *http://localhost:8080/tutelagedata/all
     */
    @GetMapping("/all")
    public Object getAllCustomers() {
    return new ResponseEntity<>(service.getAllCustomers(), HttpStatus.OK);
    }

    /**
     * Get a specific customer's information using id
     * http://localhost:8080/customers/1
     */
    @GetMapping("/{customerId}")
    public Object getCustomerById(@PathVariable int customerId) {
        return new ResponseEntity<>(service.getCustomertById(customerId), HttpStatus.OK);
    }

//    Added this so that I can have students be able to see the posts applicable
    @GetMapping("/customer/{customerId}")
    public String showCustomerDashboard(@PathVariable int customerId, Model model) {
        Customer customer = service.getCustomertById(customerId);
        List<Posting> postings = postingService.getAvailablePostings(); // Only status == false

        model.addAttribute("customer", customer);
        model.addAttribute("postings", postings);
        return "customer-dashboard"; // Your .ftlh file
    }
//
////    /**
////     * Get a list of customers under a specific course
////     *http://localhost:8080/customers/courses/csc-340
////     */
////    @GetMapping("/courses/{courseId}")
////    public Object getCustomerCourses(@PathVariable String courseId) {
////    return new ResponseEntity<>(service.getCustomersByCourseId(courseId), HttpStatus.OK);
////    }

    /**
     * Get list of all available courses/services
     * http://localhost:8080/tutelagedata/courses
     */
    @GetMapping("/courses")
    public Object getAllCourses() {
        return new ResponseEntity<>(service.getAllCourses(), HttpStatus.OK);
    }

    /**
     * Get customer's schedule based on ID
     * http://localhost:8080/tutelagedata/1/schedule
     */
    @GetMapping("/schedule/{customerId}")
    public ResponseEntity<List<String>> getCustomerSchedule(@PathVariable int customerId) {

        return new ResponseEntity<>(service.getCustomerSchedule(customerId), HttpStatus.OK);
    }

    /**
     * Get customer's subscription type
     * http://localhost:8080/tutelagedata/1/isSubscribed
     */
    @GetMapping("/subscribed/{customerId}")
    public Object getCustomerSubscription(@PathVariable int customerId) {
        return new ResponseEntity<>(service.getCustomerSubscription(customerId), HttpStatus.OK);
    }

    @GetMapping("/reviews/{customerId}")
    public Object getCustomerReviews(@PathVariable int customerId) {
        return new ResponseEntity<>(service.getCustomerSubscription(customerId), HttpStatus.OK);
    }

    /**
     * Register a new customer
     * http://localhost:8080/tutelagedata/new
     */
    @PostMapping("/new/customer")
    public String addNewCustomer(@ModelAttribute Customer customer, Model model) {
        Customer savedCustomer = service.addNewCustomer(customer);
        return "redirect:/students/userProfile/" + savedCustomer.getCustomerId();
    }

    @GetMapping("/userProfile/{customerId}")
    public String userProfile(@PathVariable("customerId") int customerId, Model model) {
        Customer customer = service.getCustomertById(customerId);
        model.addAttribute("customer", customer);
        return "user-profile";
    }

    //http://localhost:8080/tutelagedata/customer-create
    @GetMapping("/customer-create")
    public String registerNewCustomer() {
        return "register-user";
    }

//    /**
//     * Show Customer's profile
//     */
//    @GetMapping("/userProfile")
//    public String userProfile() {
//        return "user-profile";
//    }

    /**
     * Show Landing Page/Homepage
     * http://localhost:8080/tutelagedata/homepage
     */
    @GetMapping("/homepage")
    public String homepage() {
        return "landing-page";
    }

    /**
     * Show Login Page
     */
    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    // Save a posting (course) to the student's saved list
    @PostMapping("/{customerId}/save-posting/{postId}")
    public String savePostingToCustomer(@PathVariable int customerId,
                                        @PathVariable int postId) {
        service.savePostingToCustomer(customerId, postId); // This method saves the posting
        return "redirect:/students/userProfile/" + customerId; // Redirect to profile
    }

    // Remove a saved posting from the student's list
    @PostMapping("/{customerId}/remove-posting/{postId}")
    public String removePostingFromCustomer(@PathVariable int customerId,
                                            @PathVariable int postId) {
        service.removePostingFromCustomer(customerId, postId);
        return "redirect:/students/userProfile/" + customerId;
    }

    @PostMapping("/savePosting")
    public String savePostingToProfile(@RequestParam("postId") int postId, HttpSession session) {
        Customer customer = (Customer) session.getAttribute("customer");

        if (customer != null) {
            service.savePostingToCustomer(customer.getCustomerId(), postId);
            return "redirect:/user-profile";
        }

        return "redirect:/login"; // if not logged in
    }



}
